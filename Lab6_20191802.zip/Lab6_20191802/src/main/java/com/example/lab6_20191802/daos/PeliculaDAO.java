package com.example.lab6_20191802.daos;

import com.example.lab6_20191802.beans.Pelicula;
import com.example.lab6_20191802.beans.Genero;


import java.sql.*;
import java.util.ArrayList;
public class PeliculaDAO {
    public ArrayList<Pelicula> obtenerListaPeliculas(){
        ArrayList<Pelicula> listaPeliculas = new ArrayList<>();

        try {
            String user = "root";
            String pass = "root";
            String url = "jdbc:mysql://127.0.0.1:3306/mydb";

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(url, user, pass);
            Statement stmt = conn.createStatement();

            ResultSet rs = stmt.executeQuery("SELECT p.*, g.nombre FROM Pelicula p INNER JOIN Genero g ON p.idGenero = g.idGenero");

            while (rs.next()) {
                Pelicula pelicula = new Pelicula();
                pelicula.setIdPelicula(rs.getInt(1));
                pelicula.setTitulo(rs.getString(2));
                pelicula.setDirector(rs.getString(3));
                pelicula.setAnoPublicacion(rs.getInt(4));
                pelicula.setRating(rs.getDouble(5));
                pelicula.setBoxOffice(rs.getDouble(6));

                Genero genero = new Genero();
                genero.setIdGenero(rs.getInt("idGenero"));
                genero.setNombre(rs.getString("nombre"));

                pelicula.setGenero(genero);

                listaPeliculas.add(pelicula);
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return listaPeliculas;
        }
    }