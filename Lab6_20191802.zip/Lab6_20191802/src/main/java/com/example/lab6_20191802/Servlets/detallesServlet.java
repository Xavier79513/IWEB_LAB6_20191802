package com.example.lab6_20191802.Servlets;

import com.example.lab6_20191802.beans.Pelicula;
import com.example.lab6_20191802.daos.idPeliculaDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

@WebServlet(name = "DetallesServlet", value = "/DetallesServlet")
public class detallesServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int idPeliculaDAO = Integer.parseInt(request.getParameter("id"));

        idPeliculaDAO peliDao = new idPeliculaDAO();
        Pelicula pelicula = peliDao.obtenerPeliculaPorId(idPeliculaDAO);

        request.setAttribute("pelicula", pelicula);

        RequestDispatcher view = request.getRequestDispatcher("viewPelicula.jsp");
        view.forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}