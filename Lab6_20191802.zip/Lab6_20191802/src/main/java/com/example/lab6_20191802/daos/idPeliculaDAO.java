package com.example.lab6_20191802.daos;

import com.example.lab6_20191802.beans.Pelicula;
import com.example.lab6_20191802.beans.Genero;
import java.sql.*;
import com.example.lab6_20191802.utils.ConnectionFactory;

public class idPeliculaDAO {
    private static final String SELECT_BY_ID_QUERY = "SELECT p.*, g.nombre FROM Pelicula p INNER JOIN Genero g ON p.idGenero = g.idGenero WHERE idPelicula = ?";

    public Pelicula obtenerPeliculaPorId(int idPelicula) {
        Pelicula pelicula = null;
        try {
            Connection conn = ConnectionFactory.getConnection();
            PreparedStatement preparedStatement = conn.prepareStatement(SELECT_BY_ID_QUERY);
            preparedStatement.setInt(1, idPelicula);
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                pelicula = new Pelicula();
                pelicula.setIdPelicula(rs.getInt("idPelicula"));
                pelicula.setTitulo(rs.getString("titulo"));
                pelicula.setDirector(rs.getString("director"));
                pelicula.setAnoPublicacion(rs.getInt("anoPublicacion"));
                pelicula.setRating(rs.getDouble("rating"));
                pelicula.setBoxOffice(rs.getDouble("boxOffice"));

                Genero genero = new Genero();
                genero.setNombre(rs.getString("nombre"));
                pelicula.setGenero(genero);
            }
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pelicula;
    }
}