package com.example.lab6_20191802.Servlets;

import com.example.lab6_20191802.beans.Pelicula;
import com.example.lab6_20191802.daos.PeliculaDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.stream.Collectors;

@WebServlet(name = "PeliculaServlet", value = "/PeliculaServlet")
public class PeliculaServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String busqueda = request.getParameter("busqueda");

        PeliculaDAO peliculaDAO = new PeliculaDAO();
        ArrayList<Pelicula> listaPeliculas = peliculaDAO.obtenerListaPeliculas();

        // Filtrar la lista de películas si hay una cadena de búsqueda
        if (busqueda != null && !busqueda.isEmpty()) {
            listaPeliculas = listaPeliculas.stream()
                    .filter(pelicula -> pelicula.getTitulo().toLowerCase().contains(busqueda.toLowerCase()))
                    .collect(Collectors.toCollection(ArrayList::new));
        }

        request.setAttribute("lista", listaPeliculas);

        RequestDispatcher view = request.getRequestDispatcher(("paginaPeliculas.jsp"));
        view.forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}